export const logoUrl =
  "https://cdn.freelogovectors.net/wp-content/uploads/2023/01/myntra-logo-freelogovectors.net_.png";

export const accessKey = process.env.REACT_APP_ACCESS_KEY;

export const options = {
  method: "GET",
  headers: {
    "X-RapidAPI-Key": "efdb2bb2c5mshaeaff7945137945p156229jsn0c1671243231",
    "X-RapidAPI-Host": "asos2.p.rapidapi.com",
  },
};

export const productUrl =
  "https://asos2.p.rapidapi.com/products/v2/list?store=US&offset=0&categoryId=4209&limit=20&country=US&sort=freshness&currency=USD&sizeSchema=US&lang=en-US";

// console.log(accessKey);
