import React from "react";

const Login = () => {
  return (
    <div>
    <form action="">
      <h1>Sign In</h1>

    </form>
    </div>
  );
};

export default Login;
