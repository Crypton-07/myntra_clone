import React from "react";
import { logoUrl } from "../constants/constant";
import {
  SearchOutlined,
  Person2Outlined,
  FavoriteBorderOutlined,
  ShoppingBagOutlined,
} from "@mui/icons-material";
import { useSelector } from "react-redux";

const Header = () => {
  const cartItem = useSelector((store) => store?.cart?.cartItems);
  const wishlistItem = useSelector((store) => store?.cart?.wishlistItem);
  return (
    <div className="py-3 px-4 flex items-center space-x-10 justify-around shadow-md fixed z-10 bg-slate-50 w-full">
      <div>
        {/* Logo */}
        <img className="w-14 h-auto" src={logoUrl} alt="logo" />
      </div>
      {/* ul and Li */}
      <ul className="flex space-x-8 items-center font-semibold cursor-pointer">
        <li className="hover:text-red-400 transition duration-150 ease-in">
          MEN
        </li>
        <li className="hover:text-red-400 transition duration-150 ease-in">
          WOMEN
        </li>
        <li className="hover:text-red-400 transition duration-150 ease-in">
          KIDS
        </li>
        <li className="hover:text-red-400 transition duration-150 ease-in">
          HOME & LIVING
        </li>
        <li className="hover:text-red-400 transition duration-150 ease-in">
          BEAUTY
        </li>
        <li className="hover:text-red-400 transition duration-150 ease-in">
          STUDIO
        </li>
      </ul>
      <div className="flex items-center space-x-2 bg-gray-200 px-2 shadow-md">
        <input
          className="w-96 px-2 py-2 focus:outline-none bg-transparent text-gray-600 placeholder:text-gray-500"
          type="text"
          placeholder="search your luxury..."
        />
        <SearchOutlined className="w-8 h-8 text-gray-500 cursor-pointer" />
      </div>
      <div className="flex items-center space-x-8 justify-end cursor-pointer">
        <div className="flex flex-col items-center">
          <Person2Outlined className="!text-[30px] text-gray-700" />
          <p>Profile</p>
        </div>
        <div className="flex flex-col items-center relative">
          <FavoriteBorderOutlined className="!text-[25px] text-gray-700" />
          <span className="px-[6px] rounded-full absolute bottom-8 right-2 bg-red-400 text-white font-medium text-sm">
            {wishlistItem?.length}
          </span>
          <p>Whishlist</p>
        </div>
        <div className="flex flex-col items-center relative">
          <ShoppingBagOutlined className="!text-[25px] text-gray-700" />
          <span className="px-[6px] rounded-full absolute bottom-8 left-4 bg-red-400 text-white font-medium text-sm">
            {cartItem?.length}
          </span>
          <p>Bag</p>
        </div>
      </div>
    </div>
  );
};

export default Header;
