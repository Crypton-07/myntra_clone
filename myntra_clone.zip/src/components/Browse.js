import { useSelector } from "react-redux";
import useBanner from "../hooks/useBanner";
import Banner from "./Banner";
import useProductList from "../hooks/useProductList";
import ProductList from "./ProductList";

const Browse = () => {
  useBanner();
  useProductList();

  const bannerImage = useSelector((store) => store?.banner?.banner);
  return (
    <div className="relative top-24">
      <Banner bannerImage={bannerImage} />
      <ProductList />
    </div>
  );
};

export default Browse;
